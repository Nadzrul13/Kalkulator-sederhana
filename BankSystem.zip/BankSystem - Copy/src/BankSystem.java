import java.io.*;
import java.util.*;

public class BankSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("=== Selamat Datang di Bank Jujur ===");
            System.out.println("Silahkan Pilih Fitur Dibawah Ini :");
            System.out.println("1. Daftar akun baru");
            System.out.println("2. Login");
            System.out.println("3. Keluar");
            System.out.print("Masukkan Pilihan Anda : ");
            int pilihan = scanner.nextInt();
            scanner.nextLine(); // Mengonsumsi karakter newline

            switch (pilihan) {
                case 1:
                    System.out.print("Masukkan nama: ");
                    String nama = scanner.nextLine();

                    System.out.print("Masukkan saldo awal: ");
                    double saldo = scanner.nextDouble();

                    System.out.print("Masukkan tingkat bunga: ");
                    double tingkatBunga = scanner.nextDouble();

                    System.out.print("Masukkan password: ");
                    String password = scanner.next();

                    String pin;
                    boolean validPin = false;

                    do {
                        System.out.print("Masukkan PIN (6 digit): ");
                        pin = scanner.next();

                        if (pin.length() == 6) {
                            validPin = true;
                        } else {
                            System.out.println("Panjang PIN harus 6 digit. Silakan coba lagi.");
                        }
                    } while (!validPin);

                    SavingAccount akunBaru = new SavingAccount(nama, saldo, tingkatBunga, password, pin);
                    List<SavingAccount> daftarAkun = SavingAccount.bacaDariDatabase("database.txt");
                    daftarAkun.add(akunBaru);
                    SavingAccount.simpanKeDatabase("database.txt", daftarAkun);

                    System.out.println("Akun baru berhasil didaftarkan.");
                    System.out.println("Data akun baru:");
                    System.out.println("Nama: " + akunBaru.getNama());
                    System.out.println("Saldo: " + akunBaru.getSaldo());
                    System.out.println("Tingkat Bunga: " + akunBaru.getTingkatBunga());
                    break;

                case 2:
                    System.out.print("Masukkan nama: ");
                    String loginNama = scanner.nextLine();

                    System.out.print("Masukkan password: ");
                    String loginPassword = scanner.next();

                    List<SavingAccount> loginDaftarAkun = SavingAccount.bacaDariDatabase("database.txt");
                    boolean ditemukan = false;

                    for (SavingAccount akun : loginDaftarAkun) {
                        if (akun.getNama().equals(loginNama) && akun.getPassword().equals(loginPassword)) {
                            System.out.println("Selamat datang, " + akun.getNama() + "!");
                            SavingAccount.tampilkanData(loginDaftarAkun, loginNama, loginPassword);

                            int subPilihan;
                            boolean kembali = false;

                            while (!kembali) {
                                System.out.println("\nMenu:");
                                System.out.println("1. Ganti Password");
                                System.out.println("2. Penambahan Deposit");
                                System.out.println("3. Tarik Tunai");
                                System.out.println("4. Kembali");
                                System.out.print("Masukkan Pilihanmu :");

                                subPilihan = scanner.nextInt();
                                scanner.nextLine(); // Mengonsumsi karakter newline

                                switch (subPilihan) {
                                    case 1:
                                        System.out.print("Masukkan password lama: ");
                                        String passwordLama = scanner.next();

                                        System.out.print("Masukkan password baru: ");
                                        String passwordBaru = scanner.next();

                                        if (akun.getPassword().equals(passwordLama)) {
                                            akun.setPassword(passwordBaru);
                                            SavingAccount.simpanKeDatabase("database.txt", loginDaftarAkun);
                                            System.out.println("Password berhasil diganti.");
                                        } else {
                                            System.out.println("Password lama salah. Ganti password gagal.");
                                        }
                                        break;

                                    case 2:
                                        System.out.print("Masukkan jumlah deposit: ");
                                        double deposit = scanner.nextDouble();
                                        scanner.nextLine(); // Consume newline character

                                        boolean pinValid = false;
                                        while (!pinValid) {
                                            System.out.print("Masukkan PIN: ");
                                            String loginPin = scanner.next();

                                            if (akun.validatePin(loginPin)) {
                                                akun.tambahSaldo(deposit, loginPin);
                                                SavingAccount.simpanKeDatabase("database.txt", loginDaftarAkun);
                                                System.out.println("Deposit berhasil ditambahkan.");
                                                pinValid = true; // Exit the loop when the PIN is valid
                                            } else {
                                                System.out.println("PIN yang Anda masukkan salah. Silakan coba lagi.");
                                            }
                                        }
                                        break;


                                    case 3:
                                        System.out.print("Masukkan jumlah saldo yang ingin ditarik: ");
                                        double withdrawal = scanner.nextDouble();
                                        scanner.nextLine(); // Consume newline character

                                        boolean pinValid2 = false;
                                        while (!pinValid2) {
                                            System.out.print("Masukkan PIN: ");
                                            String withdrawalPin = scanner.next();

                                            if (akun.validatePin(withdrawalPin)) {
                                                if (akun.getSaldo() >= withdrawal) {
                                                    akun.kurangiSaldo(withdrawal, withdrawalPin);
                                                    SavingAccount.simpanKeDatabase("database.txt", loginDaftarAkun);
                                                    System.out.println("Penarikan berhasil dilakukan.");
                                                    pinValid2 = true; // Exit the loop when the PIN is valid
                                                } else {
                                                    System.out.println("Saldo tidak mencukupi untuk melakukan penarikan.");
                                                }
                                            } else {
                                                System.out.println("PIN yang Anda masukkan salah. Silakan coba lagi.");
                                            }
                                        }
                                        break;
                                    case 4:
                                        kembali = true;
                                        break;

                                    default:
                                        System.out.println("Pilihan tidak valid. Silakan pilih opsi yang tersedia.");
                                        break;
                                }
                            }

                            ditemukan = true;
                            break;
                        }
                    }

                    if (!ditemukan) {
                        System.out.println("Nama atau password salah. Login gagal.");
                    }
                    break;

                case 3:
                    exit = true;
                    System.out.println("Terima kasih telah menggunakan Sistem Bank. Sampai jumpa!");
                    break;

                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih opsi yang tersedia.");
                    break;
            }
        }
    }
}
