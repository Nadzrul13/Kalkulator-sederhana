import java.io.*;
import java.util.*;

class SavingAccount {
    private String nama;
    private double saldo;
    private double tingkatBunga;
    private String password;
    private String pin;

    public SavingAccount(String nama, double saldo, double tingkatBunga, String password, String pin) {
        this.nama = nama;
        this.saldo = saldo;
        this.tingkatBunga = tingkatBunga;
        this.password = password;
        this.pin = pin;
    }

    public String getNama() {
        return nama;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getTingkatBunga() {
        return tingkatBunga;
    }

    public String getPassword() {
        return password;
    }

    public String getPin() {
        return pin;
    }

    public void tambahSaldo(double jumlah, String pin) {
        if (this.pin.equals(pin)) {
            saldo += jumlah;
            System.out.println("Saldo berhasil ditambahkan. Saldo saat ini: " + saldo);
        } else {
            System.out.println("PIN yang Anda masukkan salah. Penambahan saldo gagal.");
        }
    }

    public void kurangiSaldo(double jumlah, String pin) {
        if (this.pin.equals(pin)) {
            if (saldo >= jumlah) {
                saldo -= jumlah;
                System.out.println("Peminjaman berhasil. Saldo saat ini: " + saldo);
            } else {
                System.out.println("Saldo tidak mencukupi untuk melakukan peminjaman.");
            }
        } else {
            System.out.println("PIN yang Anda masukkan salah. Peminjaman gagal.");
        }
    }


    public void calculateInterest() {
        double bunga = saldo * (tingkatBunga / 100);
        saldo += bunga;
        System.out.println("Bunga dihitung. Saldo saat ini: " + saldo);
    }

    public boolean isLoan() {
        return saldo < 0;
    }

    public static void simpanKeDatabase(String namaFile, List<SavingAccount> daftarAkun) {
        try (PrintWriter writer = new PrintWriter(new File(namaFile))) {
            for (SavingAccount akun : daftarAkun) {
                writer.println(
                        akun.getNama() + "," + akun.getSaldo() + ","
                                + akun.getTingkatBunga() + "," + akun.getPassword() + "," + akun.getPin()
                );
            }
            System.out.println("Data berhasil disimpan ke database.");
        } catch (FileNotFoundException e) {
            System.out.println("Terjadi kesalahan saat menyimpan data ke database.");
        }
    }

    public static List<SavingAccount> bacaDariDatabase(String namaFile) {
        List<SavingAccount> daftarAkun = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(namaFile))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");

                if (data.length == 5) {
                    String nama = data[0];
                    double saldo = Double.parseDouble(data[1]);
                    double tingkatBunga = Double.parseDouble(data[2]);
                    String password = data[3];
                    String pin = data[4];

                    SavingAccount akun = new SavingAccount(nama, saldo, tingkatBunga, password, pin);
                    daftarAkun.add(akun);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Terjadi kesalahan saat membaca data dari database.");
        }

        return daftarAkun;
    }

    public static void tampilkanData(List<SavingAccount> daftarAkun, String nama, String password) {
        for (SavingAccount akun : daftarAkun) {
            if (akun.getNama().equals(nama) && akun.getPassword().equals(password)) {
                System.out.println("Nama: " + akun.getNama());
                System.out.println("Saldo: " + akun.getSaldo());
                System.out.println("Tingkat Bunga: " + akun.getTingkatBunga());
                return;
            }
        }
        System.out.println("Akun tidak ditemukan.");
    }

    public void setPassword(String passwordBaru) {
        this.password = passwordBaru;
        System.out.println("Password berhasil diganti.");
    }

    public boolean validatePin(String pin) {
        return this.pin.equals(pin);
    }

}
