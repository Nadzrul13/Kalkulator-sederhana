import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Transaction transaction = new Transaction();
        Customer customer = new Customer();

        boolean isRunning = true;
        while (isRunning) {
            System.out.println("=== SELAMAT DATANG DI WARUNG HALAL ===");
            System.out.println("1. Beli");
            System.out.println("2. Keluar");
            System.out.print("Pilih menu: ");
            int menu = scanner.nextInt();
            scanner.nextLine(); // Consumes the newline character

            switch (menu) {
                case 1:
                    System.out.println("=== ANDA PUAS KAMIPUN SENANG ===");
                    transaction.processTransaction(customer);
                    break;
                case 2:
                    isRunning = false;
                    break;
                default:
                    System.out.println("Menu tidak valid.");
            }
        }

        scanner.close();
    }
}
