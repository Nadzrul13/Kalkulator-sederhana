import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Transaction {

    private Menu menu;

    public Transaction() {
        menu = new Menu();
    }

    public void processTransaction(Customer customer) {
        Scanner scanner = new Scanner(System.in);

        customer.addCustomer();

        menu.displayMenu();

        boolean isOrdering = true;
        int totalPrice = 0;
        StringBuilder transactionData = new StringBuilder();

        while (isOrdering) {
            System.out.print("\nMasukkan nomor menu ('s' untuk selesai): ");
            String input = scanner.nextLine();

            if (input.equals("s")) {
                isOrdering = false;
            } else {
                try {
                    int menuNumber = Integer.parseInt(input);

                    String menuName = menu.getMenuByNumber(menuNumber);
                    if (menuName != null) {
                        System.out.print("Masukkan jumlah item: ");
                        int quantity = scanner.nextInt();
                        scanner.nextLine(); // Consumes the newline character

                        int menuPrice = menu.getMenuItemPrice(menuName);
                        int subtotal = menuPrice * quantity;
                        totalPrice += subtotal;

                        System.out.println("Total Harga per Item: Rp." + subtotal);
                        transactionData.append(menuName).append("\t\t: ").append(quantity).append(" x ").append(menuPrice).append("\n");
                    } else {
                        System.out.println("Menu tidak tersedia.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Input tidak valid. Masukkan nomor menu atau 's' untuk selesai.");
                }
            }
        }

        System.out.println("\n=== PEMBAYARAN ===");
        boolean isPaymentValid = false;
        int totalPayment = 0;

        while (!isPaymentValid) {
            System.out.println("Total Harga: Rp." + totalPrice);
            System.out.print("Masukkan Nominal Uang Pembeli: Rp.");
            totalPayment = scanner.nextInt();
            scanner.nextLine(); // Consumes the newline character

            if (totalPayment >= totalPrice) {
                isPaymentValid = true;
            } else {
                System.out.println("\nJumlah uang yang diberikan kurang.\n");
            }
        }

        int change = totalPayment - totalPrice;
        System.out.println("Kembalian: Rp." + change);

        System.out.println("\n========== STRUK PEMBELIAN ==========");
        System.out.println("Pembeli       \t: " + customer.getName());
        System.out.println("Nomor Telepon \t: " + customer.getPhoneNumber());
        System.out.println("Alamat        \t: " + customer.getAddress());
        System.out.println("Item          \t: ");
        System.out.println(transactionData.toString());
        System.out.println("Total Harga   \t: Rp." + totalPrice);
        System.out.println("Pembayaran    \t: Rp." + totalPayment);
        System.out.println("Kembalian     \t: Rp." + change + "\n");
    }

    private void saveTransactionData(String transactionData) {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter("Transaksi_pembeli.txt", true));
            writer.println(transactionData);
            writer.close();
        } catch (IOException e) {
            System.out.println("Terjadi kesalahan saat menyimpan data transaksi.");
        }
    }

    private static class Menu {
        private Map<String, Integer> menuItems;

        public Menu() {
            menuItems = new HashMap<>();
            menuItems.put("Nasi Goreng", 15000);
            menuItems.put("Mie Ayam ", 12000);
            menuItems.put("Sate Ayam", 10000);
            menuItems.put("Gado-gado", 13000);
            menuItems.put("Nasi Padang", 18000);
            menuItems.put("Es Teh Manis", 5000);
            menuItems.put("Es Jeruk ", 6000);
            menuItems.put("Es Cendol", 7000);
            menuItems.put("Es Campur", 8000);
            menuItems.put("Jus Alpukat", 10000);
        }

        public void displayMenu() {
            System.out.println("\n========== MENU ==========\n");
            int counter = 1;
            for (String menu : menuItems.keySet()) {
                System.out.println(counter + ". " + menu + "\t- Rp" + menuItems.get(menu));
                counter++;
            }
        }

        public String getMenuByNumber(int number) {
            int counter = 1;
            for (String menu : menuItems.keySet()) {
                if (counter == number) {
                    return menu;
                }
                counter++;
            }
            return null;
        }

        public int getMenuItemPrice(String menuName) {
            return menuItems.getOrDefault(menuName, 0);
        }
    }
}
