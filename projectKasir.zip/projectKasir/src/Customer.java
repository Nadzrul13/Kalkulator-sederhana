import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Customer {
    private String name;
    private String phoneNumber;
    private String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void addCustomer() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan nama pembeli: ");
        String name = scanner.nextLine();
        setName(name);

        boolean isPhoneNumberValid = false;
        while (!isPhoneNumberValid) {
            System.out.print("Masukkan nomor telepon: ");
            String phoneNumber = scanner.nextLine();

            // Validasi nomor telepon harus berupa angka
            if (!phoneNumber.matches("\\d+")) {
                System.out.println("Nomor telepon harus berupa angka.");
                continue; // Mengulangi loop jika validasi tidak terpenuhi
            }

            // Validasi jumlah digit nomor telepon
            int phoneNumberLength = phoneNumber.length();
            if (phoneNumberLength < 11 || phoneNumberLength > 13) {
                System.out.println("Nomor telepon harus terdiri dari 11 hingga 13 digit.");
                continue; // Mengulangi loop jika validasi tidak terpenuhi
            }

            setPhoneNumber(phoneNumber);
            isPhoneNumberValid = true; // Keluar dari loop jika validasi terpenuhi
        }



        System.out.print("Masukkan alamat pembeli: ");
        String address = scanner.nextLine();
        setAddress(address);

        boolean isExisting = isCustomerExisting(name, phoneNumber, address);
        if (isExisting) {
            System.out.println("Data pembeli sudah ada.");
        } else {
            try {
                PrintWriter writer = new PrintWriter(new FileWriter("dataPembeli.txt", true));
                writer.println(name + "," + phoneNumber + "," + address);
                writer.close();
                System.out.println("\nData pembeli berhasil ditambahkan.");
            } catch (IOException e) {
                System.out.println("Terjadi kesalahan saat menambahkan data pembeli.");
            }
        }
    }

    private boolean isCustomerExisting(String name, String phoneNumber, String address) {
        List<String> customerData = readCustomerData();

        for (String data : customerData) {
            String[] customerInfo = data.split(",");
            if (customerInfo.length == 3) { // Memastikan panjang array sesuai dengan struktur data
                String customerName = customerInfo[0];
                String customerPhoneNumber = customerInfo[1];
                String customerAddress = customerInfo[2];

                if (customerName.equalsIgnoreCase(name) && customerPhoneNumber.equals(phoneNumber)
                        && customerAddress.equalsIgnoreCase(address)) {
                    return true;
                }
            }
        }

        return false;
    }

    private List<String> readCustomerData() {
        List<String> customerData = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("dataPembeli.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                customerData.add(line);
            }
        } catch (IOException e) {
            System.out.println("Terjadi kesalahan saat membaca data pembeli.");
        }

        return customerData;
    }
}
